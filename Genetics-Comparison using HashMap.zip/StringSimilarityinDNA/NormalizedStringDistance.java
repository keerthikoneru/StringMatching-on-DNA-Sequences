package StringSimilarityinDNA;

public interface NormalizedStringDistance extends StringDistance {
    
}