package StringSimilarityinDNA;

public class LCS implements StringDistance {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public double distance(String s1, String s2) {
		return s1.length() + s2.length() - 2 * length(s1, s2);
	}

	/**
	 * Return the length of Longest Common Subsequence (LCS) between strings s1
	 * and s2.
	 *
	 * @param s1
	 * @param s2
	 * @return the length of LCS(s1, s2)
	 */
	protected int length(String s1, String s2) {

		int m = s1.length();
		int n = s2.length();
		char[] X = s1.toCharArray();
		char[] Y = s2.toCharArray();

		int[][] C = new int[m + 1][n + 1];

		for (int i = 0; i <= m; i++) {
			C[i][0] = 0;
		}

		for (int j = 0; j <= n; j++) {
			C[0][j] = 0;
		}

		for (int i = 1; i <= m; i++) {
			for (int j = 1; j <= n; j++) {
				if (X[i - 1] == Y[j - 1]) {
					C[i][j] = C[i - 1][j - 1] + 1;

				} else {
					C[i][j] = Math.max(C[i][j - 1], C[i - 1][j]);
				}
			}
		}

		return C[m][n];
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see Genetics.StringDistance#jarodistance(java.lang.String,
	 * java.lang.String)
	 */
	@Override
	public double jarodistance(String s1, String s2) {
		return 0;
	}

}
