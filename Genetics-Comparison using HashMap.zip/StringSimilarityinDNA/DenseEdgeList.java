package StringSimilarityinDNA;

/**
 * @author keerthi
 *
 */
class DenseEdgeList implements EdgeList {
	private State[] array;

	public DenseEdgeList() {
		this.array = new State[256];
		for (int i = 0; i < array.length; i++)
			this.array[i] = null;
	}

	/**
	 * @param list
	 * @return denseEdgelist
	 */
	public static DenseEdgeList fromSparse(SparseEdgeList list) {
		byte[] keys = list.keys();
		DenseEdgeList newInstance = new DenseEdgeList();
		for (int i = 0; i < keys.length; i++) {
			newInstance.put(keys[i], list.get(keys[i]));
		}
		return newInstance;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see Genetics.EdgeList#get(byte)
	 */
	public State get(byte b) {
		return this.array[(int) b & 0xFF];
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see Genetics.EdgeList#put(byte, Genetics.State)
	 */
	public void put(byte b, State s) {
		this.array[(int) b & 0xFF] = s;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see Genetics.EdgeList#keys()
	 */
	public byte[] keys() {
		int length = 0;
		for (int i = 0; i < array.length; i++) {
			if (array[i] != null)
				length++;
		}
		byte[] result = new byte[length];
		int j = 0;
		for (int i = 0; i < array.length; i++) {
			if (array[i] != null) {
				result[j] = (byte) i;
				j++;
			}
		}
		return result;
	}

}
