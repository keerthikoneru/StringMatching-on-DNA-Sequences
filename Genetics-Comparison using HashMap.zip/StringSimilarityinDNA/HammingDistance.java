package StringSimilarityinDNA;

/**
 * @author keerthi
 *
 */
public class HammingDistance {
	/**
	 * @param sequence1
	 * @param sequence2
	 * @return HammingDistance
	 */
	public int getHammingDistance(String sequence1, String sequence2) {

		int distance = 0;
		if (sequence1 == null || sequence2 == null)
			System.exit(0);

		if (sequence1.length() != sequence2.length()) {
			System.out
					.println("The string are not equal in length ,Please enter the strings wit equal lengths ");
		}

		for (int i = 0; i < sequence1.length(); i++) {
			if (sequence1.charAt(i) != sequence2.charAt(i))
				distance++;
		}
		return distance;

	}

}
