package StringSimilarityinDNA;

public interface NormalizedStringSimilarity extends StringSimilarity {
    
}