package StringSimilarityinDNA;
import java.io.Serializable;


public interface StringDistance extends Serializable {

    public double distance(String s1, String s2);
    public double jarodistance(String s1, String s2);
}