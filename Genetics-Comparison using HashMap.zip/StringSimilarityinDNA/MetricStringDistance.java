package StringSimilarityinDNA;

public interface MetricStringDistance extends StringDistance {
    public double distance(String s1, String s2);
}

