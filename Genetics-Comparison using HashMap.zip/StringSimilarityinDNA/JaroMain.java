package StringSimilarityinDNA;


import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;


/**
 * @author keerthi
 *
 */
public class JaroMain {

	public static void main(String[] args) throws IOException,
			ClassNotFoundException, SQLException {
		JaroWrinkler jw = new JaroWrinkler();
		long timeStart = System.currentTimeMillis();
		Runtime runtime = Runtime.getRuntime();
		String url = "jdbc:sqlserver://CIHAN-PC\\SQLEXPRESS;databaseName=DNASequence;integratedSecurity=true";
		Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
		Connection con;
		con = DriverManager.getConnection(url);
		String pattern = "aagccggcccagcccgttcg";
		PreparedStatement sequenceset = con
				.prepareStatement("select * from sequence1;");
		PreparedStatement sequences = con
				.prepareStatement("select * from sequence1 where id in (?, ?, ?, ?, ?);");
		String inputtext = null;
		ResultSet result1 = sequenceset.executeQuery();
		System.out.println(pattern);
		Map<Integer, Integer> h = new HashMap<Integer, Integer>();
		int x = 0;
		while (result1.next()) {
			inputtext = result1.getString("sequence").replaceAll("\\s+", "");
			h.put(x, 0);
			for (int i = 0; i + (pattern.length() - 1) < inputtext.length(); i++) {
				String p = inputtext.substring(i, i + pattern.length());
				if (jw.jarosimilarity(p, pattern) > 0.9) {
					h.put(x, h.get(x)+1);
				}
			}
			x++;
		}
		
		List<Map.Entry<Integer, Integer>> entries = sortByValues(h);

		sequences.setInt(1, entries.get(entries.size()-1).getKey());
		sequences.setInt(2, entries.get(entries.size()-2).getKey());
		sequences.setInt(3, entries.get(entries.size()-3).getKey());
		sequences.setInt(4, entries.get(entries.size()-4).getKey());
		sequences.setInt(5, entries.get(entries.size()-5).getKey());
		ResultSet result2 = sequences.executeQuery();

		while (result2.next()) {
			System.out.println("" + result2.getInt("id") + "\t"
					+ result2.getString("sequence").replaceAll("\\s+", ""));
		}
		long allocatedMemory = runtime.totalMemory();
		System.out.println(allocatedMemory / 1024.0);
		long timeEnd = System.currentTimeMillis();
		System.out.println("Process time: " + (timeEnd - timeStart) / 1000);

	}
	
	@SuppressWarnings("rawtypes")
	public static <K extends Comparable,V extends Comparable> List<Map.Entry<K, V>> sortByValues(Map<K,V> map){
        List<Map.Entry<K,V>> entries = new LinkedList<Map.Entry<K,V>>(map.entrySet());
      
        Collections.sort(entries, new Comparator<Map.Entry<K,V>>() {

            @SuppressWarnings("unchecked")
			@Override
            public int compare(Entry<K, V> o1, Entry<K, V> o2) {
                return o1.getValue().compareTo(o2.getValue());
            }

        });
        
        System.out.println(entries.get(entries.size()-1).getKey() + " " + entries.get(entries.size()-2).getKey() 
        		+ " " + entries.get(entries.size()-3).getKey() + " " + entries.get(entries.size()-4).getKey()
				+ " " + entries.get(entries.size()-5).getKey());
        
        System.out.println(entries.get(entries.size()-1).getValue() + " " + entries.get(entries.size()-2).getValue() 
        		+ " " + entries.get(entries.size()-3).getValue() + " " + entries.get(entries.size()-4).getValue()
				+ " " + entries.get(entries.size()-5).getValue());
        
        /*Map<K,V> sortedMap = new LinkedHashMap<K,V>();
        
        for(Map.Entry<K,V> entry: entries){
            sortedMap.put(entry.getKey(), entry.getValue());
        }
      
        return sortedMap;*/
        
        return entries;
    }

}
