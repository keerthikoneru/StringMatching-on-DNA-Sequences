package StringSimilarityinDNA;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

public class DataProcessing {

	public static void main(String[] args) throws IOException {
		BufferedReader CSVFile1 = new BufferedReader(new FileReader("C:\\Users\\Cihan\\Desktop\\input.csv"));
		ArrayList<String> al = new ArrayList<String>();
		String dataRow1 = CSVFile1.readLine();
		while (dataRow1 != null) {

			String input=dataRow1;
			String output = input.replaceAll("[^a-z]", "");
			al.add(output);
			dataRow1 = CSVFile1.readLine();
        }
		int size = al.size();
		FileWriter writer1=new FileWriter("C:\\Users\\Cihan\\Desktop\\output.csv");
		while(size!=0)
        {
			size--;
			writer1.append(""+al.get(size));
            writer1.append('\n');
        }
		 CSVFile1.close();
		 writer1.close();

	}

}
