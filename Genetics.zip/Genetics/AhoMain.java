package Genetics;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public class AhoMain {

	@SuppressWarnings("unchecked")
	public static void main(String[] args) throws ClassNotFoundException,
			SQLException {
		AhoCorasick tree = new AhoCorasick();
		long timeStart = System.currentTimeMillis();
		String url = "jdbc:sqlserver://CIHAN-PC\\SQLEXPRESS;databaseName=DNASequence;integratedSecurity=true";
		Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
		Connection con;
		con = DriverManager.getConnection(url);
		Runtime runtime = Runtime.getRuntime();

		String[] terms = { "aagccggcccagcccgttcg", };
		for (int i = 0; i < terms.length; i++) {
			tree.add(terms[i].getBytes(), terms[i]);
		}
		tree.prepare();
		PreparedStatement sequenceset = con
				.prepareStatement("select * from sequence1;");
		String inputtext = null;
		ResultSet result1 = sequenceset.executeQuery();
		while (result1.next()) {
			inputtext = result1.getString("sequence").replaceAll("\\s+", "");
			Set<String> termsThatHit = new HashSet<String>();
			for (Iterator<SearchResult> iter = tree
					.search(inputtext.getBytes()); iter.hasNext();) {
				SearchResult result = iter.next();
				termsThatHit.addAll(result.getOutputs());
			}
			if (termsThatHit.size() > 0) {
				System.out.println(result1.getInt("id"));
			}
			termsThatHit.forEach(element -> System.out.println(element));

		}

		long allocatedMemory = runtime.totalMemory();
		System.out.println(allocatedMemory / 1024.0);

		long timeEnd = System.currentTimeMillis();
		System.out.println("Process time: " + (timeEnd - timeStart) / 1000);
	}

}
