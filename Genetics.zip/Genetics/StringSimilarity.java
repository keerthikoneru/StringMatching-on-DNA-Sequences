package Genetics;

import java.io.Serializable;

public interface StringSimilarity extends Serializable {
   
    public double jwsimilarity(String s1, String s2);
    public double jarosimilarity(String s1, String s2);
    
}
