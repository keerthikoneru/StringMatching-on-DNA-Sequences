package Genetics;

public class LCSEx {
	
	public LCSEx() {
	}

	/**
	 * @param x
	 * @param y
	 * @return 
	 */
	public String distance(String x, String y) {
		int M = x.length();
		int N = y.length();

		int[][] opt = new int[M + 1][N + 1];

		// compute length of LCS and all subproblems via dynamic programming
		for (int i = M - 1; i >= 0; i--) {
			for (int j = N - 1; j >= 0; j--) {
				if (x.charAt(i) == y.charAt(j))
					opt[i][j] = opt[i + 1][j + 1] + 1;
				else
					opt[i][j] = Math.max(opt[i + 1][j], opt[i][j + 1]);
			}
		}

		// recover LCS itself and print it to standard output
		int i = 0, j = 0;
		String p = "";
		while (i < M && j < N) {
			if (x.charAt(i) == y.charAt(j)) {
				p = p + x.charAt(i);
				i++;
				j++;
			} else if (opt[i + 1][j] >= opt[i][j + 1])
				i++;
			else
				j++;
		}

		return p;
	}

}
