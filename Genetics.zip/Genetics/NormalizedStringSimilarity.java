package Genetics;

public interface NormalizedStringSimilarity extends StringSimilarity {
    
}