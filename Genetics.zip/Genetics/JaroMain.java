package Genetics;


import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Arrays;


/**
 * @author keerthi
 *
 */
public class JaroMain {

	public static void main(String[] args) throws IOException,
			ClassNotFoundException, SQLException {
		JaroWrinkler jw = new JaroWrinkler();
		long timeStart = System.currentTimeMillis();
		Runtime runtime = Runtime.getRuntime();
		String url = "jdbc:sqlserver://CIHAN-PC\\SQLEXPRESS;databaseName=DNASequence;integratedSecurity=true";
		Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
		Connection con;
		con = DriverManager.getConnection(url);
		String pattern = "aagccggcccagcccgttcg";
		PreparedStatement sequenceset = con
				.prepareStatement("select * from sequence1;");
		PreparedStatement sequences = con
				.prepareStatement("select * from sequence1 where id in (?, ?, ?, ?, ?);");
		String inputtext = null;
		ResultSet result1 = sequenceset.executeQuery();
		System.out.println(pattern);
		int[] count = new int[1000];
		int x = 0;
		while (result1.next()) {
			inputtext = result1.getString("sequence").replaceAll("\\s+", "");
			for (int i = 0; i + (pattern.length() - 1) < inputtext.length(); i++) {
				String p = inputtext.substring(i, i + pattern.length());
				if (jw.jarosimilarity(p, pattern) > 0.9) {
					count[x]++;
				}
			}
			x++;
		}
		int[] countcopy = count.clone();
		Arrays.sort(countcopy);

		int index1 = -1, index2 = -1, index3 = -1, index4 = -1, index5 = -1;
		for (int i = 0; i < count.length - 1; i++) {
			int c = count[i];
			if (c == countcopy[count.length - 1] && index1 == -1)
				index1 = i;
			else if (c == countcopy[count.length - 2] && index2 == -1)
				index2 = i;
			else if (c == countcopy[count.length - 3] && index3 == -1)
				index3 = i;
			else if (c == countcopy[count.length - 4] && index4 == -1)
				index4 = i;
			else if (c == countcopy[count.length - 5] && index5 == -1)
				index5 = i;
		}

		System.out.println(index1 + " " + index2 + " " + index3 + " " + index4
				+ " " + index5);

		sequences.setInt(1, index1);
		sequences.setInt(2, index2);
		sequences.setInt(3, index3);
		sequences.setInt(4, index4);
		sequences.setInt(5, index5);
		ResultSet result2 = sequences.executeQuery();

		while (result2.next()) {
			System.out.println("" + result2.getInt("id") + "\t"
					+ result2.getString("sequence").replaceAll("\\s+", ""));
		}
		long allocatedMemory = runtime.totalMemory();
		System.out.println(allocatedMemory / 1024.0);
		long timeEnd = System.currentTimeMillis();
		System.out.println("Process time: " + (timeEnd - timeStart) / 1000);

	}
}
