package Genetics;

public interface NormalizedStringDistance extends StringDistance {
    
}